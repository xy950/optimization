function error_fitness = calculate_error(q,q1_goal,q2_goal,q3_goal,q4_goal)   
    eq1=q(1)-q1_goal;
    eq2=q(2)-q2_goal;
    eq3=q(3)-q3_goal;
    eq4=q(4)-q4_goal;

    error_fitness = eq1^2+eq2^2+eq3^2+eq4^2;
end
