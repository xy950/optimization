clc;
clear;
close all;
% 读取数据
% data = load('your_data_file.mat'); % 你需要将此处的'your_data_file.mat'替换为你的实际数据文件名
% target_angles = data.target_angles;
% actual_angles = data.actual_angles;

% 设置优化参数
alpha = 0.01;
batch_size = 2;%100;
maxIter = 2;%100;
Ps = 2;%100;
LengthOfProblem = 4;

% 初始化参数
maxOuterIter = 2;%10; % 最外层循环的最大迭代次数
improvementThreshold = 1e-6; % 当改进的程度小于这个阈值时，停止迭代

% 初始化参数
A =1000* rand(Ps, LengthOfProblem);
B = 500*rand(Ps, LengthOfProblem);
C = 5*rand(Ps, 1);
D = rand(Ps, 2);
D = D ./ sum(D, 2);
D_size = [Ps, 2];  % D矩阵的大小
% 定义你的机器人参数
% robot_parameters = struct('target_angles', target_angles, 'actual_angles', actual_angles);

for outerIter = 1:maxOuterIter
% 首先，优化A, B, C
[A_opt, B_opt, C_opt,fitness] = optimize_ABC(D, A, B, C, alpha, batch_size, maxIter, Ps, LengthOfProblem);
%里面嵌套了使用evaluate_fitness这个函数

% 然后，优化D
% % D_fitness = optimize_D(A_opt, B_opt, C_opt,D);
% % options = optimoptions('gamultiobj', 'PopulationSize', Ps, 'MaxGenerations', 50);
% % D_opt = gamultiobj(@optimize_D, 2, [], [], [], [], zeros(1, 2), ones(1, 2), [], options);
% % 
% % % D_opt = gamultiobj(@optimize_D, 2, [], [], [], [], zeros(1, 2), ones(1, 2), [], options);
% % 
% % optimize_D_wrapper = @(D) optimize_D(A_opt, B_opt, C_opt, D);
% % options = optimoptions('gamultiobj', 'PopulationSize', Ps, 'MaxGenerations', 50);
% % D_opt = gamultiobj(optimize_D_wrapper, 2, [], [], [], [], zeros(1, 2), ones(1, 2), [], options);
% % 
% % options = optimoptions('ga','PlotFcn',@gaplotbestf);
% % [x,Fval] = ga(@optimize_D,2,[],[],[],[],lb,ub,options);

fitness = @(D) optimize_D(D, A_opt, B_opt, C_opt);
options = optimoptions('ga', 'PopulationSize', Ps, 'MaxGenerations', 50);
[D_opt, fval] = ga(fitness, numel(D_size), [], [], [], [], [0, 0], [1, 1], [], options);

% 获取最优的 D(jj,1) 和 D(jj,2) 值
best_fit = fval;
best_D1 = D_opt(1);
best_D2 = D_opt(2);

% 计算适应度改进的程度
fitness_old=fitness;
[~,~,fitness_new,~,~,~,~,~,~] = evaluate_fitness(A_opt, B_opt, C_opt, 1,D_opt);
improvement = abs(fitness_new - fitness_old);
    
% 检查是否达到了停止准则
if improvement < improvementThreshold
   break;
end

% 为下一个循环更新A, B, C, D
A = A_opt;
B = B_opt;
C = C_opt;
D = D_opt;
end

% 保存优化后的参数
save('optimized_parameters.mat', 'A_opt', 'B_opt', 'C_opt', 'D_opt');

mean_fitness = mean(fitnesses, 2);
max_fitness = max(fitnesses, [], 2);
min_fitness = min(fitnesses, [], 2);

figure;
plot(1:size(fitnesses, 1), mean_fitness, 'b', 'LineWidth', 2); hold on;
plot(1:size(fitnesses, 1), max_fitness, 'g', 'LineWidth', 2); hold on;
plot(1:size(fitnesses, 1), min_fitness, 'r', 'LineWidth', 2); hold off;
xlabel('Generation');
ylabel('Fitness');
legend('Mean Fitness', 'Max Fitness', 'Min Fitness');

mean_params = cellfun(@(x) mean(x, 1), params, 'UniformOutput', false);
mean_A = cellfun(@(x) x(1), mean_params);
mean_B = cellfun(@(x) x(2), mean_params);
mean_C = cellfun(@(x) x(3), mean_params);
mean_D = cellfun(@(x) x(4), mean_params);

figure;
plot(1:length(mean_params), mean_A, 'r', 'LineWidth', 2); hold on;
plot(1:length(mean_params), mean_B, 'g', 'LineWidth', 2); hold on;
plot(1:length(mean_params), mean_C, 'b', 'LineWidth', 2); hold on;
plot(1:length(mean_params), mean_D, 'k', 'LineWidth', 2); hold off;
xlabel('Generation');
ylabel('Parameter Value');
legend('A', 'B', 'C', 'D');


% Compute the Pareto front
pareto_front = paretofront(fitnesses);

% Plot the Pareto front
figure;
plot(fitnesses(~pareto_front, 1), fitnesses(~pareto_front, 2), 'ko'); hold on; % non-Pareto solutions
plot(fitnesses(pareto_front, 1), fitnesses(pareto_front, 2), 'ro'); % Pareto solutions
xlabel('Error Fitness');
ylabel('Stability Fitness');
legend('Non-Pareto Solutions', 'Pareto Solutions');
