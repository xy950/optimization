function x_theta=compute_state(t,z,flag,tau)
theta1=z(1); theta2=z(2); theta3=z(3); theta4=z(4); theta5=z(5);
dtheta1=z(6);dtheta2=z(7);dtheta3=z(8);dtheta4=z(9);dtheta5=z(10);
tau1=tau(1);tau2=tau(2);tau3=tau(3);tau4=tau(4);
m1=2.23;m2=5.28;m3=14.79;
m4=m2;m5=m1;
I1=0.033;I2=0.033;I3=0.033;I4=0.033;I5=0.033;
L1=0.332;L2=0.302;L3=0.486;L4=L2;L5=L1;
d1=0.189;d2=0.236;d3=0.282;d4=d2;d5=d1;
g=9.81;

D = [            (m2 + m3 + m4 + m5)*L1^2 + m1*d1^2 + I1, cos(theta1 - theta2)*(L1*d2*m2 + L1*L2*(m3 + m4 + m5)), L1*d3*m3*cos(theta1 - theta3), cos(theta1 + theta4)*(L1*L4*m5 + L1*m4*(L4 - d4)), L1*m5*cos(theta1 + theta5)*(L5 - d5);
 cos(theta1 - theta2)*(L1*d2*m2 + L1*L2*(m3 + m4 + m5)),                     (m3 + m4 + m5)*L2^2 + m2*d2^2 + I2, L2*d3*m3*cos(theta2 - theta3), cos(theta2 + theta4)*(L2*L4*m5 + L2*m4*(L4 - d4)), L2*m5*cos(theta2 + theta5)*(L5 - d5);
                         L1*d3*m3*cos(theta1 - theta3),                          L2*d3*m3*cos(theta2 - theta3),                  m3*d3^2 + I3,                                                 0,                                    0;
     cos(theta1 + theta4)*(L1*L4*m5 + L1*m4*(L4 - d4)),      cos(theta2 + theta4)*(L2*L4*m5 + L2*m4*(L4 - d4)),                             0,                     I4 + L4^2*m5 + m4*(L4 - d4)^2, L4*m5*cos(theta4 - theta5)*(L5 - d5);
                   L1*m5*cos(theta1 + theta5)*(L5 - d5),                   L2*m5*cos(theta2 + theta5)*(L5 - d5),                             0,              L4*m5*cos(theta4 - theta5)*(L5 - d5),                  I5 + m5*(L5 - d5)^2];
 

 T = [tau1;tau2 - tau1;tau3 - tau2;tau3 + tau4;-tau4];
%  T=[0;tau1;tau2;tau3;tau4];
 
 G =[ -g*sin(theta1)*(d1*m1 + L1*(m2 + m3 + m4 + m5));
      -g*sin(theta2)*(d2*m2 + L2*(m3 + m4 + m5));
                            -d3*g*m3*sin(theta3);
            g*sin(theta4)*(L4*m5 + m4*(L4 - d4));
                      g*m5*sin(theta5)*(L5 - d5)];
                  
h =[ sin(theta1 - theta2)*(L1*d2*m2 + L1*L2*(m3 + m4 + m5))*dtheta2^2 + L1*d3*m3*sin(theta1 - theta3)*dtheta3^2 - sin(theta1 + theta4)*(L1*L4*m5 + L1*m4*(L4 - d4))*dtheta4^2 - L1*m5*sin(theta1 + theta4)*(L5 - d5)*dtheta5^2;
 - sin(theta1 - theta2)*(L1*d2*m2 + L1*L2*(m3 + m4 + m5))*dtheta1^2 + L2*d3*m3*sin(theta2 - theta3)*dtheta3^2 - sin(theta2 + theta4)*(L2*L4*m5 + L2*m4*(L4 - d4))*dtheta4^2 - L2*m5*sin(theta2 + theta5)*(L5 - d5)*dtheta5^2;
                                                                                                                                         - L1*d3*m3*sin(theta1 - theta3)*dtheta1^2 - L2*d3*m3*sin(theta2 - theta3)*dtheta2^2;
                                                - sin(theta1 + theta4)*(L1*L4*m5 + L1*m4*(L4 - d4))*dtheta1^2 - sin(theta2 + theta4)*(L2*L4*m5 + L2*m4*(L4 - d4))*dtheta2^2 + L4*m5*sin(theta4 - theta5)*(L5 - d5)*dtheta5^2;
                                                                          - L1*m5*sin(theta1 + theta5)*(L5 - d5)*dtheta1^2 - L2*m5*sin(theta2 + theta5)*(L5 - d5)*dtheta2^2 - L4*m5*sin(theta4 - theta5)*(L5 - d5)*dtheta4^2];
 
                  

                                                            
ddtheta=inv(D)*(T-G-h);    
x_theta=[dtheta1,dtheta2,dtheta3,dtheta4,dtheta5,ddtheta']';
 
end
                                                            
 
                  
 