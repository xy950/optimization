% 输出函数
function stop = gaOutputFcn(state,flag,D)
    % 检查是否为迭代过程中的输出
    if strcmp(flag, 'iter')
        % 获取当前迭代的最佳个体
        bestIndividual = state.Best(end, :);
        
        % 绘制 D(1) 和 D(2) 的变化曲线
        plot(state.Generation, bestIndividual(1), 'ro');
        hold on;
        plot(state.Generation, bestIndividual(2), 'bo');
        xlabel('Generation');
        ylabel('D');
        legend('D(1)', 'D(2)');
        title('Optimization Progress');
        hold off;
        
        drawnow;  % 实时显示图形
    end
    
    stop = false;
end