% % function D_fitness = optimize_D(D)
% %     D_fitness = evaluate_fitness2(A_opt, B_opt, C_opt,D,jj); 
% % end

  % [A_opt, B_opt, C_opt] = optimize_ABC2(D, A, B, C, alpha, batch_size, maxIter, Ps, LengthOfProblem,jj);

  function fitness = optimize_D(D,A_opt, B_opt, C_opt)
    Ps = size(D, 1);
    fitness = zeros(Ps, 1);

  for jj=1:Ps
    [error_fitness,stability_fitness] = evaluate_fitness2(A_opt, B_opt, C_opt,D,jj); 
    fitness(jj)=D(jj,1)*error_fitness+D(jj,2)*stability_fitness;
  end
  end