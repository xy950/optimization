clear all
clc

syms m1 m2 m3 m4 m5 g real
syms L1 L2 L3 L4 L5 real
syms d1 d2 d3 d4 d5 real
syms I1 I2 I3 I4 I5 real
syms theta1 theta2 theta3 theta4 theta5 dtheta1 dtheta2 dtheta3 dtheta4 dtheta5 real
syms q0 q1 q2 q3 q4 real
syms xb yb xe ye dxe dye ve real
syms xc1 xc2 xc3 xc4 xc5 yc1 yc2 yc3 yc4 yc5 cgx cgy real
syms tau1 tau2 tau3 tau4 tau5 real

%%�þ��ԽǼ������ģ��%%
xe=xb+L1*sin(theta1)+L2*sin(theta2)+L4*sin(theta4)+L5*sin(theta5); %�ڶ���ĩ�˶˵��λ������
ye=yb+L1*cos(theta1)+L2*cos(theta2)-L4*cos(theta4)-L5*cos(theta5);

dxe=L1*cos(theta1)*dtheta1+L2*cos(theta2)*dtheta2+L4*cos(theta4)*dtheta4+L5*cos(theta5)*dtheta5; %�ڶ���ĩ�˶˵���ٶ�
dye=-L1*sin(theta1)*dtheta1-L2*sin(theta2)*dtheta2+L4*sin(theta4)*dtheta4+L5*sin(theta5)*dtheta5;

ve=[dxe;dye];

xc1=d1*sin(theta1); %ÿ���������ĵ�����
yc1=d1*cos(theta1);
xc2=L1*sin(theta1)+d2*sin(theta2);
yc2=L1*cos(theta1)+d2*cos(theta2);
xc3=L1*sin(theta1)+L2*sin(theta2)+d3*sin(theta3);
yc3=L1*cos(theta1)+L2*cos(theta2)+d3*cos(theta3);
xc4=L1*sin(theta1)+L2*sin(theta2)+(L4-d4)*sin(theta4);
yc4=L1*cos(theta1)+L2*cos(theta2)-(L4-d4)*cos(theta4);
xc5=L1*sin(theta1)+L2*sin(theta2)+L4*sin(theta4)+(L5-d5)*sin(theta5);
yc5=L1*cos(theta1)+L2*cos(theta2)-L4*cos(theta4)-(L5-d5)*cos(theta5);
xB=xb+L1*sin(theta1); %ÿ���˵������
yB=yb+L1*cos(theta1);
xC=xB+L2*sin(theta2);
yC=yB+L2*cos(theta2);
xD=xC+L3*sin(theta3);
yD=yC+L3*cos(theta3);
xE=xC+L4*sin(theta4);
yE=yC-L4*cos(theta4);
A=[xb;yb]; B=[xB;yB]; C=[xC;yC];
DD=[xD;yD]; E=[xE;yE]; F=[xe;ye];

cgx=(m1*xc1+m2*xc2+m3*xc3+m4*xc4+m5*xc5)/(m1+m2+m3+m4+m5); %���������ĵ�����
cgy=(m1*yc1+m2*yc2+m3*yc3+m4*yc4+m5*yc5)/(m1+m2+m3+m4+m5);

%%����Ϊ���ԽǵĶ���ѧģ�� D*ddtheta+h+G=T  %%

theta=[theta1 theta2 theta3 theta4 theta5]';
E=[1 0 0 0 ;-1 1 0 0;0 -1 1 0;0 0 1 1;0 0 0 -1];
tau=[tau1 tau2 tau3 tau4 ]';
T=E*tau;

p12=m2*d2*L1+(m3+m4+m5)*L1*L2;
p13=m3*L1*d3;
p14=m4*L1*(L4-d4)+m5*L1*L4;
p15=m5*L1*(L5-d5);

p23=m3*L2*d3;
p24=m4*L2*(L4-d4)+m5*L2*L4;
p25=m5*L2*(L5-d5);

p45=m5*L4*(L5-d5);

D11=I1+m1*d1^2+(m2+m3+m4+m5)*L1^2;
D12=p12*cos(theta1-theta2);
D13=p13*cos(theta1-theta3);
D14=p14*cos(theta1+theta4);
D15=p15*cos(theta1+theta5);
D21=D12;
D22=I2+m2*d2^2+(m3+m4+m5)*L2^2;
D23=p23*cos(theta2-theta3);
D24=p24*cos(theta2+theta4);
D25=p25*cos(theta2+theta5);
D31=D13;
D32=D23;
D33=I3+m3*d3^2;
D34=0; D35=0;
D41=D14;
D42=D24;
D43=0; D34=0;
D44=I4+m4*(L4-d4)^2+m5*L4^2;
D45=p45*cos(theta4-theta5);
D51=D15;
D52=D25;
D53=0;D35=0;
D54=D45;
D55=I5+m5*(L5-d5)^2;
D=[ D11 D12 D13 D14 D15;
    D21 D22 D23 D24 D25;
    D31 D32 D33 D34 D35;
    D41 D42 D43 D44 D45;
    D51 D52 D53 D54 D55];

h122=p12*sin(theta1-theta2);  h133=p13*sin(theta1-theta3);
h144=-p14*sin(theta1+theta4); h155=-p15*sin(theta1+theta4);
h211=-p12*sin(theta1-theta2); h233=p23*sin(theta2-theta3);
h244=-p24*sin(theta2+theta4); h255=-p25*sin(theta2+theta5);
h311=-p13*sin(theta1-theta3); h322=-p23*sin(theta2-theta3);
h344=0;
h355=0;
h411=-p14*sin(theta1+theta4); h422=-p24*sin(theta2+theta4);
h433=0; h455=p45*sin(theta4-theta5);
h511=-p15*sin(theta1+theta5); h522=-p25*sin(theta2+theta5);
h533=0; h544=-p45*sin(theta4-theta5);

h1=sum([h122*(dtheta2^2),h133*(dtheta3^2),h144*(dtheta4^2),h155*(dtheta5^2)]);
h2=sum([h211*(dtheta1^2),h233*(dtheta3^2),h244*(dtheta4^2),h255*(dtheta5^2)]);
h3=sum([h311*(dtheta1^2),h322*(dtheta2^2),h344*(dtheta4^2),h355*(dtheta5^2)]);
h4=sum([h411*(dtheta1^2),h422*(dtheta2^2),h433*(dtheta3^2),h455*(dtheta5^2)]);
h5=sum([h511*(dtheta1^2),h522*(dtheta2^2),h533*(dtheta3^2),h544*(dtheta4^2)]);

h=[h1 h2 h3 h4 h5]';

G1=-[m1*d1+(m2+m3+m4+m5)*L1]*g*sin(theta1);
G2=-[m2*d2+(m3+m4+m5)*L2]*g*sin(theta2);
G3=-[m3*d3]*g*sin(theta3);
G4=[m4*(L4-d4)+m5*L4]*g*sin(theta4);
G5=[m5*(L5-d5)]*g*sin(theta5);
G=[G1 G2 G3 G4 G5]';

% ddtheta=inv(D)*(T-G-h); %��þ��Խǵļ��ٶ�

%% ����Ѿ��Խ�thetaת������Խ�q %%
q1=theta1-theta2; q2=theta2-theta3; q3=theta3+theta4; q4=theta4-theta5;

%%����Ϊ��ԽǵĶ���ѧģ��D(q)*ddq+h(q)+G(q)=T(q) %%
 
q=[q0 q1 q2 q3 q4]';

for i=1:5
    A(1,i)= D(1,i)+D(2,i)+D(3,i)-D(4,i)-D(5,i);
    A(2,i)=-D(2,i)-D(3,i)+D(4,i)+D(5,i);
    A(3,i)=-D(3,i)+D(4,i)+D(5,i);
    A(4,i)= D(4,i)+D(5,i);
    A(5,i)=-D(5,i);
end
for i=1:5
    Dq(i,1)= A(i,1)+A(i,2)+A(i,3)-A(i,4)-A(i,5);
    Dq(i,2)=-A(i,2)-A(i,3)+A(i,4)+A(i,5);
    Dq(i,3)=-A(i,3)+A(i,4)+A(i,5);
    Dq(i,4)= A(i,4)+A(i,5);
    Dq(i,5)=-A(i,5);
end

hq0=h1+h2+h3-h4-h5;
hq1=-h2-h3+h4+h5;
hq2=-h3+h4+h5;
hq3=h4+h5;
hq4=-h5;
hq=[hq0 hq1 hq2 hq3 hq4]';

Gq0=G1+G2+G3-G4+G5;
Gq1=-G2-G3+G4+G5;
Gq2=-G3+G4+G5;
Gq3=G4+G5;
Gq4=-G5;
Gq=[Gq0 Gq1 Gq2 Gq3 Gq4]';

Tq0=0;
Tq1=tau1;
Tq2=tau2;
Tq3=tau3;
Tq4=tau4;
Tq=[Tq0 Tq1 Tq2 Tq3 Tq4];

% ddq=inv(Dq)*(Tq-Gq-hq); 

%%˫�Ŷ��ڿ��е�ģ��Da*ddtheta(a)+ha+Ga=Ta %%
theta_a=[theta1 theta2 theta3 theta4 theta5 xb yb]';
Ga(1)=G1; Ga(2)=G2; G(3)=G3; G(4)=G4; G(5)=G5;
Ga(6)=0;  Ga(7)=(m1+m2+m3+m4+m5)*g;
Ga=[Ga(1) Ga(2) Ga(3) Ga(4) Ga(5) Ga(6) Ga(7)]';

for i=1:5
    for j=1:5
    %Da(i,j)=Dij;
    eval(['Da(i,j)=D',num2str(i),num2str(j),';']);
    end
end
p16=m1*d1*(m2+m3+m4+m5)*L1;
p17=p16;
p26=m2*d2+(m3+m4+m5)*L2;
p27=p26;
p36=m3*d3;
p37=p36;
p46=m4*(L4-d4)+m5*L4;
p47=p46;
p56=m5*(L5-d5);
p57=p56;

Da(1,6)=p16*cos(theta1);
Da(1,7)=-p17*sin(theta1);
Da(2,6)=p26*cos(theta2);
Da(2,7)=-p27*sin(theta2);
Da(3,6)=p36*cos(theta3);
Da(3,7)=-p37*sin(theta3);
Da(4,6)=p46*cos(theta4);
Da(4,7)=p47*sin(theta4);
Da(5,6)=p56*cos(theta5);
Da(5,7)=p57*sin(theta5);
Da(6,6)=m1+m2+m3+m4+m5;
Da(6,7)=0;
Da(7,6)=0;
Da(7,7)=Da(6,6);


for i=1:5
    Da(6,i)=Da(i,6);
    Da(7,i)=Da(i,7);
    Ta(i)=T(i);
    ha(i)=h(i);
end
Ta(6)=0;
Ta(7)=0;
ha(6)=-p16*dtheta1^2*sin(theta1)-p26*dtheta2^2*sin(theta2)-p36*dtheta3^2*sin(theta3)...
        -p46*dtheta4^2*sin(theta4)-p56*dtheta5^2*sin(theta5);
ha(7)=-p17*dtheta1^2*cos(theta1)-p27*dtheta2^2*cos(theta2)-p37*dtheta3^2*cos(theta3)...
      +p47*dtheta4^2*cos(theta4)+p57*dtheta5^2*cos(theta5);
      
% ddtheta_a=Da\(Ta-ha-Ga);

%%����Ϊ��ײģ��%%
Ja=jacobian([xe,ye],theta_a');  
dtheta_a=[dtheta1 dtheta2 dtheta3 dtheta4 dtheta5 0 0]';
dxe=Ja*dtheta_a;

%%�Ƶ����˶�ѧģ��%%
% E=0.5*velocity_body^2;
% x_apex=(-2*yC*E/g)^0.5;
q1=theta1-theta2; q2=theta2-theta3; q3=theta3+theta4; q4=theta4-theta5;

% xx=L4*sin(theta4)+L5*sin(theta5);
% yy=L4*cos(theta4)+L5*cos(theta5);
eqn1=xx==L4*sin(theta4)+L5*sin(theta5);
eqn2=yy==L4*cos(theta4)+L5*cos(theta5);

theta4= 2*atan((2*L4*xx - (- L4^4 + 2*L4^2*L5^2 + 2*L4^2*xx^2 + 2*L4^2*yy^2 - L5^4 + 2*L5^2*xx^2 + 2*L5^2*yy^2 - xx^4 - 2*xx^2*yy^2 - yy^4)^(1/2))/(L4^2 + 2*L4*yy - L5^2 + xx^2 + yy^2));
theta5= 2*atan((2*L5*xx + ((- L4^2 + 2*L4*L5 - L5^2 + xx^2 + yy^2)*(L4^2 + 2*L4*L5 + L5^2 - xx^2 - yy^2))^(1/2))/(- L4^2 + L5^2 + 2*L5*yy + xx^2 + yy^2));



    






