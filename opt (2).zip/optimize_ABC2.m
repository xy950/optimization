function [A_opt, B_opt, C_opt] = optimize_ABC2(D, A, B, C, alpha, batch_size, maxIter, Ps, LengthOfProblem,jj)
    % Loop over the maximum number of iterations
    no=0;
    fitness=[];
    for iter = 1:maxIter
        % Shuffle the population
        shuffle = randperm(Ps);
        A = A(shuffle, :);
        B = B(shuffle, :);
        C = C(shuffle, :);

        % Loop over the population in batches
        for k = 1:batch_size:Ps 
            % Extract the current batch of individuals
            A_batch = A(k:min(k+batch_size-1, Ps), :);
            B_batch = B(k:min(k+batch_size-1, Ps), :);
            C_batch = C(k:min(k+batch_size-1, Ps), :);
        
    
            % Loop over each individual in the batch
            for i = 1:size(A_batch, 1)
                % Compute the fitness of the current individual
                
                [~,~,fitness_old,~,~,~,~,~,~] = evaluate_fitness2(A_batch(i, :), B_batch(i, :), C_batch(i, :),Ps,D,jj);
                no=no+1;
                % Compute the gradients for A, B and C
                grad_A = zeros(1, LengthOfProblem);
                grad_B = zeros(1, LengthOfProblem);
                grad_C = zeros(1, 1);
                for joint = 1:LengthOfProblem
                    A_new = A_batch(i, :);
                    A_new(joint) = A_new(joint) + 1e-5;
                    [~,~,fitness_new,~,~,~,~,~,~] = evaluate_fitness2(A_new, B_batch(i, :), C_batch(i, :),Ps,D,jj);
                    grad_A(joint) = (fitness_new - fitness_old) / 1e-5;
                     no=no+1;
                    B_new = B_batch(i, :);
                    B_new(joint) = B_new(joint) + 1e-5;
                    [~,~,fitness_new,~,~,~,~,~,~] = evaluate_fitness2(A_batch(i, :), B_new, C_batch(i, :),Ps,D);
                    grad_B(joint) = (fitness_new - fitness_old) / 1e-5;
                     no=no+1;
                    % C_new = C_batch(i, :);
                    % C_new(joint) = C_new(joint) + 1e-5;
                    % fitness_new = evaluate_fitness(A_batch(i, :), B_batch(i, :), C_batch(i, :),j,D);
                    % grad_C(joint) = (fitness_new - fitness_old) / 1e-5;
                end
                    C_new = C_batch(i, :);
                    C_new = C_new + 1e-5;
                    [error_fitness,stability_fitness,fitness_new,q4_goal,q3_goal,q1_goal,q2_goal,q,dq] = evaluate_fitness2(A_batch(i, :), B_batch(i, :), C_new,Ps,D,jj);
                    grad_C = (fitness_new - fitness_old) / 1e-5;
                     no=no+1;

                % Update the weights with the computed gradients
                A_batch(i, :) = update_weights(A_batch(i, :), grad_A, alpha);
                B_batch(i, :) = update_weights(B_batch(i, :), grad_B, alpha);
                C_batch(i, :) = update_weights(C_batch(i, :), grad_C, alpha);

            end

            % Update the individuals in the batch
            A(k:min(k+batch_size-1, Ps), :) = A_batch;
            B(k:min(k+batch_size-1, Ps), :) = B_batch;
            C(k:min(k+batch_size-1, Ps), :) = C_batch;
        end
    end


    % Find the optimal A, B, C
    [~, bestIdx] = max(fitness);
    A_opt = A(bestIdx, :);
    B_opt = B(bestIdx, :);
    C_opt = C(bestIdx, :);
end
