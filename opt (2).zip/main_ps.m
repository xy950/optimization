clc
clear
close all
tic;
global fit1 fit2
% 参数数量
num_vars = 10;

% 初始范围
lower_bounds = [zeros(1, 8), 0, 0];
upper_bounds = [1000*ones(1, 4), 500*ones(1, 4), 5, 1];

% 初始解
x0 = mean([lower_bounds; upper_bounds]);

% 使用模式搜索算法进行优化

% options = optimoptions('patternsearch', 'OutputFcn', @psoutputfun, 'MaxIterations', 2, 'UseParallel', true, 'Display', 'iter');
% [x, fval] = patternsearch(@fitnessFunc, x0, [], [], [], [], lower_bounds, upper_bounds, [], options);

options = optimoptions('patternsearch', 'OutputFcn', @psoutputfun, 'MaxIterations', 40, 'UseParallel', true, 'Display', 'iter');
[x, fval] = patternsearch(@fitnessFunc, x0, [], [], [], [], lower_bounds, upper_bounds, [], options);



% 输出最优解
disp(x);
toc;
elapsedTime = toc;
fprintf('Total time taken: %.2f seconds\n', elapsedTime);
% 绘图
% 获取x的历史数据
xHistory = evalin('base','xHistory');
 
if ~isempty(xHistory)
    figure(1);
    hold on;
    for i = 1:num_vars
        plot(1:size(xHistory, 1), xHistory(:, i));
    end
    title('x Values over Iterations');
    xlabel('Iteration');
    ylabel('Values');
    legend(arrayfun(@(i) sprintf('x%d', i), 1:num_vars, 'UniformOutput', false));
    hold off;
end

% 首先从基础工作区获取历史数据
fit1History = evalin('base','fit1History');
fit2History = evalin('base','fit2History');
fitnessHistory = evalin('base','fitnessHistory');

figure(2);
plot(1:length(fitnessHistory), fitnessHistory);
title('Fitness Values over Iterations');
xlabel('Iteration');
ylabel('Fitness Value');

figure(3);
plot(1:length(fit1History), fit1History, 'b');
hold on;
plot(1:length(fit2History), fit2History, 'r');
title('Fit1 and Fit2 Values over Iterations');
xlabel('Iteration');
ylabel('Values');
legend('Fit1', 'Fit2');

figure(4);
plot(fit1History, fit2History, 'o');
title('Pareto Front');
xlabel('Fitness 1');
ylabel('Fitness 2');


function [y,fit1,fit2] = fitnessFunc(x)
    A = x(1:4);
    B = x(5:8);
    C = x(9);
    d1 = x(10);
    d2 = 1-d1;

    [error_fitness,stability_fitness]= evaluate_fitness2(A,B,C);

    % TODO: 插入用于计算fit1和fit2的代码
    fit1 = error_fitness;
    fit2 = stability_fitness;

    y = d1 * fit1 + d2 * fit2;
end


function [stop, options, optchanged] = psoutputfun(optimValues, options, flag)
    global fit1 fit2
    persistent fit1History fit2History fitnessHistory paramsHistory xHistory
    stop = false;
    optchanged = false;
    disp(['Current iteration: ', num2str(optimValues.iteration)]);
    switch flag
        case 'init'
            fit1History = [];
            fit2History = [];
            fitnessHistory = [];
            paramsHistory = [];
            xHistory = [];
        case 'iter'
            bestIndividual = optimValues.x;
            [y, fit1, fit2] = fitnessFunc(bestIndividual);
            fit1History = [fit1History; fit1];
            fit2History = [fit2History; fit2];
            fitnessHistory = [fitnessHistory; y];
            paramsHistory = [paramsHistory; bestIndividual];
            xHistory = [xHistory; bestIndividual];

            assignin('base', 'fit1History', fit1History);
            assignin('base', 'fit2History', fit2History);
            assignin('base', 'fitnessHistory', fitnessHistory);
            assignin('base', 'paramsHistory', paramsHistory);
            assignin('base', 'xHistory', xHistory);
    end
end






