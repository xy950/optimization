function [error_fitness,stability_fitness,fitness]= evaluate_fitness2(A_batch,B_batch,C_batch,D)

ToRad = pi/180;
ToAngle = 180/pi;
time_number=1000;
T=0.4;
options=odeset('abstol',1e-9,'reltol',1e-9);
z0 = [0*ToRad 0*ToRad 0*ToRad 0*ToRad 0*ToRad 0 0 0 0 0];
tau = [0 0 0 0]';
tspan=linspace(0,0.001,101);
xe=0;ye=0;
t=0;
test_record=[];test_record1=[];xbody_record=[];
tau1_record=[]; tau2_record=[]; tau3_record=[]; tau4_record=[];
phase_record=[];
q1goal_record=[];q2goal_record=[];q4goal_record=[];q3goal_record=[];
q1_record=[];q2_record=[];q4_record=[];q3_record=[];
dq1_record=[];dq2_record=[];dq3_record=[];dq4_record=[];
e_vector=[];de_vector=[];t_record=[];
yy_record=[];xx_record=[];xe_record=[];ye_record=[];
x_apex_record=[];enew_record=[];a=[];
q31_goal=0;mohu33=0;mohu44=0;x_body=0;
velocity_temp=0;acc_temp=0;xb=0;yb=0;
yC=0.6;sum_a=0;sum_alast=0;
sx=0;hh=0;ttt=0;
error_fitness=[];
stability_fitness=[];
fitness=[];
runnum=1100;

for ii=1:runnum
    clc
    t=t+0.001;
    
    [t1213,x_theta]=ode113('compute_state',tspan,z0,options,tau);
    
    x0=x_theta(end,:);
    z0=x0;
    theta1=x0(1);theta2=x0(2);theta3=x0(3);
    theta4=x0(4);theta5=x0(5);
    dtheta1=x0(6);dtheta2=x0(7);dtheta3=x0(8);
    dtheta4=x0(9);dtheta5=x0(10);
    theta=[theta1 theta2 theta3 theta4 theta5]';
    dtheta=[dtheta1;dtheta2;dtheta3;dtheta4;dtheta5];
    [re,rc]=computeFK(theta,xb,yb);
    xb=re(1,1);
    yb=re(2,1);
    re(1,:)=re(1,:)+xe;
    re(2,:)=re(2,:)+ye;
    rc(1,:)=rc(1,:)+xe;
    rc(2,:)=rc(2,:)+ye;
    tt=0.001*ii;
    velocity_goal=v_fun(tt);
    kp=0.1+0.01*tt;
    kp=-kp;
    k=0.6;

    velocity_body=(rc(1,3)-x_body)/0.001;
    velocity_body=0.9*velocity_temp+0.1*velocity_body;
    velocity_temp=velocity_body;
    e_body=velocity_body-velocity_goal;
    e_vector(ii)=e_body;
    if ii>1
        de_vector(ii)=(e_vector(ii)-e_vector(ii-1))/0.001;
    else
       de_vector(ii)=0;  
    end
    acc=de_vector(ii);
    acc=0.75*acc_temp+0.25*acc;
    acc_temp=acc;

    if ii==1
        e_new=kp*e_body;
    else
            if e_vector(ii)*de_vector(ii)<0||de_vector(ii)==0
            e_new=kp*e_body-0.01*acc;%k*kp*sum_a-0.01*acc;
            else
            e_new=kp*e_body+k*kp*e_body;%-0.01*acc;%sum_alast-0.01*acc; 
            end
    end
    x_body=rc(1,3);    
    theta_input=[theta' dtheta']';
    Rflag=1;Lflag=0;
    
    if re(2,end)<= -0.001&&t>T/4%-0.005
        t=0;
        theta_output=impact_model(theta_input);
        theta1=theta_output(5);
        theta2=theta_output(4);
        theta3=theta_output(3);
        theta4=theta_output(2);
        theta5=theta_output(1);
        dtheta1=theta_output(10);
        dtheta2=theta_output(9);
        dtheta3=theta_output(8);
        dtheta4=theta_output(7);
        dtheta5=theta_output(6);
        theta=[theta1 theta2 theta3 theta4 theta5]';
        dtheta=[dtheta1;dtheta2;dtheta3;dtheta4;dtheta5];
        
        xe=re(1,end);ye=re(2,end);        
        xe_record=[xe_record,xe];
        z0=[theta',dtheta'];
        Rflag=0;Lflag=1;
    end

     x_tau=compute_x_tau_state(t,z0,flag,x_theta);
     [tau,q4_goal,q3_goal,q1_goal,q2_goal,Rflag,q,dq,xx,yyyy,x_apex]=Controller_A(z0',t,velocity_body,xb,yb,ii,e_new,Rflag,x_tau,mohu33,mohu44,A_batch,B_batch,C_batch);
    q=[1 -1 0 0 0;0 1 -1 0 0;0 0 1 1 0;0 0 0 1 -1 ]*z0(1,1:5)';
    dq=[1 -1 0 0 0;0 1 -1 0 0;0 0 1 1 0;0 0 0 1 -1 ]*z0(1,6:10)';

    x_f=[re(1,1),re(1,2),re(1,3),re(1,4),re(1,3),re(1,5),re(1,6)];
    y_f=[re(2,1),re(2,2),re(2,3),re(2,4),re(2,3),re(2,5),re(2,6)];
     if (mod(ii,60)==0)
        plot(x_f,y_f,'Linewidth',1),axis equal,xlim([-1 1]),ylim([-1 1])
        hold on;
        plot([-10,10],[0,0],'k','linewidth',1);
        xlim([-0.5 1.5]),ylim([-0.5 1.5])
        hold off;
        pause(0.01);
        hold on
     end

    if mod(ii, 100) == 0
    eq1 = q(1) - q1_goal;
    eq2 = q(2) - q2_goal;
    eq3 = q(3) - q3_goal;
    eq4 = q(4) - q4_goal;
    error_fitness(end+1) = eq1^2 + eq2^2 + eq3^2 + eq4^2;
    stability_fitness(end+1) = dq(1)^2 + dq(2)^2 + dq(3)^2 + dq(4)^2;
    fitness(end+1)=D(1)*error_fitness(end)+D(2)*stability_fitness(end);
    end
    
    % % if ii==runnum/2
    % % eq1 = q(1) - q1_goal;
    % % eq2 = q(2) - q2_goal;
    % % eq3 = q(3) - q3_goal;
    % % eq4 = q(4) - q4_goal;
    % % error_fitness(end+1) = eq1^2 + eq2^2 + eq3^2 + eq4^2;
    % % stability_fitness(end+1) = dq(1)^2 + dq(2)^2 + dq(3)^2 + dq(4)^2;
    % % fitness(end+1)=D(1)*error_fitness(1)+D(2)*stability_fitness(1);
    % % end
    % % 
    % %  if ii==runnum
    % % eq1 = q(1) - q1_goal;
    % % eq2 = q(2) - q2_goal;
    % % eq3 = q(3) - q3_goal;
    % % eq4 = q(4) - q4_goal;
    % % error_fitness(end+1) = eq1^2 + eq2^2 + eq3^2 + eq4^2;
    % % stability_fitness(end+1) = dq(1)^2 + dq(2)^2 + dq(3)^2 + dq(4)^2;
    % % fitness(end+1)=D(1)*error_fitness(2)+D(2)*stability_fitness(2);
    % %  end

     q1goal_record=[q1goal_record,q1_goal];
     q2goal_record=[q2goal_record,q2_goal];
     q1_record=[q1_record,q(1)];
     q2_record=[q2_record,q(2)];
     q4goal_record=[q4goal_record,q4_goal];
     q3goal_record=[q3goal_record,q3_goal];
     q4_record=[q4_record,q(4)];
     q3_record=[q3_record,q(3)];
     dq1_record=[dq1_record,dq(1)];
     dq2_record=[dq2_record,dq(2)];
     dq3_record=[dq3_record,dq(3)];
     dq4_record=[dq4_record,dq(4)];

     % if ii==2
     %     break
     % end

     end
     error_fitness=mean(error_fitness);
     stability_fitness=mean(stability_fitness);
     fitness=mean(fitness);
end

  