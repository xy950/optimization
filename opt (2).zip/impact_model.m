function theta_output=impact_model(theta_input)

m1=2.23;m2=5.28;m3=14.79;
m4=m2;m5=m1;
I1=0.033;I2=0.033;I3=0.033;I4=0.033;I5=0.033;
L1=0.332;L2=0.302;L3=0.486;L4=L2;L5=L1;
d1=0.189;d2=0.236;d3=0.282;d4=d2;d5=d1;
theta1=theta_input(1);
theta2=theta_input(2);
theta3=theta_input(3);
theta4=theta_input(4);
theta5=theta_input(5);
dtheta1=theta_input(6);
dtheta2=theta_input(7);
dtheta3=theta_input(8);
dtheta4=theta_input(9);
dtheta5=theta_input(10);
dtheta_a=[dtheta1 dtheta2 dtheta3 dtheta4 dtheta5 0 0]';


Da =[                (m2 + m3 + m4 + m5)*L1^2 + m1*d1^2 + I1, cos(theta1 - theta2)*(L1*d2*m2 + L1*L2*(m3 + m4 + m5)), L1*d3*m3*cos(theta1 - theta3), cos(theta1 + theta4)*(L1*L4*m5 + L1*m4*(L4 - d4)), L1*m5*cos(theta1 + theta5)*(L5 - d5), L1*d1*m1*cos(theta1)*(m2 + m3 + m4 + m5), -L1*d1*m1*sin(theta1)*(m2 + m3 + m4 + m5);
 cos(theta1 - theta2)*(L1*d2*m2 + L1*L2*(m3 + m4 + m5)),                     (m3 + m4 + m5)*L2^2 + m2*d2^2 + I2, L2*d3*m3*cos(theta2 - theta3), cos(theta2 + theta4)*(L2*L4*m5 + L2*m4*(L4 - d4)), L2*m5*cos(theta2 + theta5)*(L5 - d5),  cos(theta2)*(d2*m2 + L2*(m3 + m4 + m5)),  -sin(theta2)*(d2*m2 + L2*(m3 + m4 + m5));
                          L1*d3*m3*cos(theta1 - theta3),                          L2*d3*m3*cos(theta2 - theta3),                  m3*d3^2 + I3,                                                 0,                                    0,                        d3*m3*cos(theta3),                        -d3*m3*sin(theta3);
      cos(theta1 + theta4)*(L1*L4*m5 + L1*m4*(L4 - d4)),      cos(theta2 + theta4)*(L2*L4*m5 + L2*m4*(L4 - d4)),                             0,                     I4 + L4^2*m5 + m4*(L4 - d4)^2, L4*m5*cos(theta4 - theta5)*(L5 - d5),       cos(theta4)*(L4*m5 + m4*(L4 - d4)),        sin(theta4)*(L4*m5 + m4*(L4 - d4));
                   L1*m5*cos(theta1 + theta5)*(L5 - d5),                   L2*m5*cos(theta2 + theta5)*(L5 - d5),                             0,              L4*m5*cos(theta4 - theta5)*(L5 - d5),                  I5 + m5*(L5 - d5)^2,                 m5*cos(theta5)*(L5 - d5),                  m5*sin(theta5)*(L5 - d5);
               L1*d1*m1*cos(theta1)*(m2 + m3 + m4 + m5),                cos(theta2)*(d2*m2 + L2*(m3 + m4 + m5)),             d3*m3*cos(theta3),                cos(theta4)*(L4*m5 + m4*(L4 - d4)),             m5*cos(theta5)*(L5 - d5),                   m1 + m2 + m3 + m4 + m5,                                         0;
              -L1*d1*m1*sin(theta1)*(m2 + m3 + m4 + m5),               -sin(theta2)*(d2*m2 + L2*(m3 + m4 + m5)),            -d3*m3*sin(theta3),                sin(theta4)*(L4*m5 + m4*(L4 - d4)),             m5*sin(theta5)*(L5 - d5),                                        0,                    m1 + m2 + m3 + m4 + m5];
 


 Ja =[  L1*cos(theta1),  L2*cos(theta2), 0, L4*cos(theta4), L5*cos(theta5), 1, 0;
       -L1*sin(theta1), -L2*sin(theta2), 0, L4*sin(theta4), L5*sin(theta5), 0, 1];
  
dxe =[L1*dtheta1*cos(theta1) + L2*dtheta2*cos(theta2) + L4*dtheta4*cos(theta4) + L5*dtheta5*cos(theta5);
     L4*dtheta4*sin(theta4) - L2*dtheta2*sin(theta2) - L1*dtheta1*sin(theta1) + L5*dtheta5*sin(theta5)];
 
dtheta_output=dtheta_a+inv(Da)*Ja'*inv(Ja*inv(Da)*Ja')*(dxe); 
theta_output=[theta_input(1:5)',dtheta_output(1:5)']';

end