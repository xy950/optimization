function [A_opt, B_opt, C_opt,best_fitness,fitness_evolution,error_evolution,stability_evolution] = optimize_ABC(D, A, B, C, alpha, batch_size, maxIter, Ps, LengthOfProblem)
    D=[0.68,032];
    % 初始化最佳个体及其适应度
    best_A = [];
    best_B = [];
    best_C = [];
    best_fitness = Inf;
    fitness_evolution = zeros(maxIter, 1);  % 存储适应度演化曲线数据
    error_evolution=zeros(maxIter, 1);
    stability_evolution=zeros(maxIter, 1);

    % Loop over the maximum number of iterations
    no=0;
    for iter = 1:maxIter
        % Shuffle the population
        shuffle = randperm(Ps);
        A = A(shuffle, :);
        B = B(shuffle, :);
        C = C(shuffle, :);
        % 显示进度
        fprintf('First Processing %d out of %d...\n', iter, maxIter);

        % Loop over the population in batches
        for kk = 1:batch_size:Ps 
        % 显示进度
        fprintf('Second Processing %d out of %d...\n', kk, Ps);


            % Extract the current batch of individuals
            A_batch = A(kk:min(kk+batch_size-1, Ps), :);
            B_batch = B(kk:min(kk+batch_size-1, Ps), :);
            C_batch = C(kk:min(kk+batch_size-1, Ps), :);

            fitness_batch = Inf(size(A_batch, 1), 1);
            error_batch = zeros(size(A_batch, 1), 1);
            stability_batch = zeros(size(A_batch, 1), 1);


            % Loop over each individual in the batch
            parfor i = 1:size(A_batch, 1)
                % Compute the fitness of the current individual
                [~,~,fitness_old] = evaluate_fitness2(A_batch(i, :), B_batch(i, :), C_batch(i, :),D,i,kk,iter);
                no=no+1;
                % Compute the gradients for A, B and C
                grad_A = zeros(1, LengthOfProblem);
                grad_B = zeros(1, LengthOfProblem);
                grad_C = zeros(1, 1);
                for joint = 1:LengthOfProblem
                    A_new = A_batch(i, :);
                    A_new(joint) = A_new(joint) + 1e-5;
                    [~,~,fitness_new] = evaluate_fitness2(A_new, B_batch(i, :), C_batch(i, :),D,i,kk,iter);
                    grad_A(joint) = (fitness_new - fitness_old) / 1e-5;
                     no=no+1;
                    B_new = B_batch(i, :);
                    B_new(joint) = B_new(joint) + 1e-5;
                    [~,~,fitness_new] = evaluate_fitness2(A_batch(i, :), B_new, C_batch(i, :),D,i,kk,iter);
                    grad_B(joint) = (fitness_new - fitness_old) / 1e-5;
                     no=no+1;
 
                end
                    C_new = C_batch(i, :);
                    C_new = C_new + 1e-5;
                    [error_fitness,stability_fitness,fitness_new] = evaluate_fitness2(A_batch(i, :), B_batch(i, :), C_new,D,i,kk,iter);
                    grad_C = (fitness_new - fitness_old) / 1e-5;
                     no=no+1;

                % Update the weights with the computed gradients
                A_batch(i, :) = update_weights(A_batch(i, :), grad_A, alpha);
                B_batch(i, :) = update_weights(B_batch(i, :), grad_B, alpha);
                C_batch(i, :) = update_weights(C_batch(i, :), grad_C, alpha);

                fitness_batch(i) = fitness_new;
                error_batch(i) = error_fitness;
                stability_batch(i) = stability_fitness;

                %disp(i);
                fprintf("i=%f\n",i);
                % 显示进度
                fprintf('Third Processing %d out of %d...\n', i, size(A_batch, 1));

            end
            % Update the individuals in the batch
            A(kk:min(kk+batch_size-1, Ps), :) = A_batch;
            B(kk:min(kk+batch_size-1, Ps), :) = B_batch;
            C(kk:min(kk+batch_size-1, Ps), :) = C_batch;

            [min_fitness, idx] = min(fitness_batch);
            if min_fitness < best_fitness
                best_fitness = min_fitness;
                best_A = A_batch(idx, :);
                best_B = B_batch(idx, :);
                best_C = C_batch(idx, :);
            end
%                   % 更新最佳个体及其适应度
%                 if fitness_new < best_fitness
%                     best_A = A_batch(i, :);
%                     best_B = B_batch(i, :);
%                     best_C = C_batch(i, :);
%                     best_fitness = fitness_new;
%                 end
            fitness_evolution(iter) = best_fitness;
            error_evolution(iter) = error_batch(idx);
            stability_evolution(iter) = stability_batch(idx);
            %disp(k);
            fprintf("kk=%f\n",kk);
        end
        %disp(iter);
        fprintf("iter=%f\n",iter);
      end

    A_opt = best_A;
    B_opt = best_B;
    C_opt = best_C;

    A=real(A);
    B=real(B);
    C=real(C);
   save('optimized_ABC0702.mat','A','B','C', 'A_opt', 'B_opt', 'C_opt', 'D','fitness_evolution','error_evolution','stability_evolution');

% 假设 A、B 和 C 是已知的矩阵
figure;
imagesc(A);
colormap('jet');
colorbar;
xlabel('Column Index');
ylabel('Row Index');
title('Heatmap of Matrix A');

figure;
imagesc(B);
colormap('jet');
colorbar;
xlabel('Column Index');
ylabel('Row Index');
title('Heatmap of Matrix B');

figure;
imagesc(C);
colormap('jet');
colorbar;
xlabel('Column Index');
ylabel('Row Index');
title('Heatmap of Matrix C');

% 绘制散点矩阵图
figure;
scatter3(A(:, 1), A(:, 2), C, 'r');
hold on;
scatter3(B(:, 1), B(:, 2), C, 'g');
xlabel('A(:, 1)');
ylabel('A(:, 2)');
zlabel('C');
title('Scatter Matrix Plot');
legend('A', 'B');

% 合并 A、B 和 C 到一个矩阵中
data = [A_opt, C_opt, B_opt];

% 绘制平行坐标图
figure;
parallelcoords(data, 'labels', {'A1', 'A2', 'A3', 'A4', 'C', 'B1', 'B2', 'B3', 'B4'});
title('Parallel Coordinates Plot');

end
