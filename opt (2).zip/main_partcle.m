clc
clear
close all

nvars = 11; % 参数数量
lb = zeros(1, nvars); % 下界
ub = [1000*ones(1, 8), 5, 1, 1]; % 上界
% options = optimoptions('particleswarm', 'MaxIterations', 2); % 设定最大迭代次数
% [x, fval] = particleswarm(@fitnessFunc, nvars, lb, ub, options); % 运行粒子群优化

history = []; % 初始化变量以保存参数历史
fitHistory = []; % 初始化变量以保存适应度历史
options = optimoptions('particleswarm', 'MaxIterations', 1, ...
    'OutputFcn', @(optimValues, state) outputFunc(optimValues, state)); % 设定最大迭代次数和输出函数

[x, fval] = particleswarm(@fitnessFunc, nvars, lb, ub, options); % 运行粒子群优化


% 输出最优解
disp(x);

figure;
plot(1:1000, x(1:4), 'b'); % PD控制器参数c1
hold on;
plot(1:1000, x(5:8), 'r'); % PD控制器参数c2
hold on
plot(1:1000, x(9), 'g'); % 阈值a
hold on
plot(1:1000, x(10:11), 'c'); % d1 d2
hold on
plot(1:1000, fval, 'k'); % 适应度值
hold off;
legend('PD Controller Parameter c1', 'PD Controller Parameter c2', 'Threshold a', 'Fitness');



figure;
plot(history);
title('Parameter Values over Generations');
xlabel('Generation');
ylabel('Parameter Values');
legend('c1','c2','a','d1','d2');

figure;
plot(fitnessHistory);
title('Fitness Values over Generations');
xlabel('Generation');
ylabel('Fitness Value');

figure;
plot(fit1, fit2, 'o');
title('Pareto Front');
xlabel('Fitness 1');
ylabel('Fitness 2');

function fit = fitnessFunc(params)
    A = params(1:4); % 提取PD控制器参数c1
    B = params(5:8); % 提取PD控制器参数c2
    C = params(9); % 提取阈值a
    d1 = params(10);
    d2 = params(11);
    
    % 计算fit1和fit2
    % 这将需要你具体的模型和控制策略
    [error_fitness,stability_fitness,fitness]= evaluate_fitness2(A,B,C);

    % TODO: 插入用于计算fit1和fit2的代码
    fit1 = error_fitness;
    fit2 = stability_fitness;
    
    % 计算总的适应度
    fit = d1 * fit1 + d2 * fit2;
end


function stop = outputFunc(optimValues, state)
    % 定义输出函数以保存参数历史和适应度历史
    stop = false; % 这是必须的，表示优化是否应该停止
    history = [history; optimValues.xbest']; % 保存最佳参数值
    fitHistory = [fitHistory; optimValues.fbest]; % 保存最佳适应度值
end

