% 假设有一个4个关节（rows）× 7种方法（columns）× N个数据点的三维数组数据
% 这里我们使用随机数来模拟数据
N = 100; % 数据点数目
data = rand(N, 4, 7); % 生成随机数据

% 创建图形窗口
figure;

% 遍历每个关节和每种方法
for i = 1:4 % 对于4个关节
    for j = 1:7 % 对于7种方法
        % 计算子图位置
        subplotIndex = (i - 1) * 7 + j;
        subplot(4, 7, subplotIndex); % 选择子图位置
        
        % 绘制数据，这里我们只是用线性索引绘制对应的数据
        plot(data(:, i, j));
        
        % 添加标题
        title(sprintf('Joint %d, Method %d', i, j));
        
        % 可以选择只在外围子图显示坐标轴标签
        if i ~= 4
            set(gca, 'XTickLabel', []); % 隐藏除了最下面一行之外的所有x轴标签
        end
        if j ~= 1
            set(gca, 'YTickLabel', []); % 隐藏除了最左边一列之外的所有y轴标签
        end
        
        % 设置一个限制，使得所有子图的坐标轴都相同
        xlim([1 N]); % 假设时间序列或试验次数为1到N
    end
end

% 自动调整子图之间的间距以防止标签重叠
% MATLAB R2019b及之后的版本可以使用sgtitle添加整个图形的标题
sgtitle('Joint Angles Following for Different Methods');

% 调整布局
tight_layout(); % MATLAB没有内置的tight_layout函数，但你可以自己调整subplot参数
