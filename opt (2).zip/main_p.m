clc;
clear;
close all;


% 设置优化参数
alpha = 0.2;%最开始0.01
batch_size = 10;%100;
maxIter = 10;%100;
Ps = 10;%100;
LengthOfProblem = 4;

% 初始化参数
A =1000* rand(Ps, LengthOfProblem);
B = 500*rand(Ps, LengthOfProblem);
C = 5*rand(Ps, 1);
D=[0.68,032];

% % [error_fitness,stability_fitness] = evaluate_fitness();
% % fun = @(d) d(1)*error_fitness+ d(2)*stability_fitness;
% % 
% % % 定义约束
% % Aeq = [1 1];
% % beq = 1;
% % lb = [0; 0];
% % ub = [1; 1];
% % 
% % 
% % % 定义遗传算法参数
% % gaOptions = optimoptions('ga', 'PlotFcn', @gaplotbestf, 'Display', 'iter','PopulationSize', 25, 'MaxGenerations', 50);
% % 
% % [D, fval, exitflag,output,population,scores]= ga(fun, 2, [], [], Aeq, beq, lb, ub, [], gaOptions);

% % % 打印每次优化的 x 值
% % disp(D)
% % % disp(population(1:10,:))
% % 
% % figure;
% % plot(population, 'r-', 'LineWidth', 2);
% % 
% % % 打印最优的D(1)和D(2)
% % fprintf('The optimal D(1) = %.2f, D(2) = %.2f\n', D(1), D(2));

tic;
% 再优化A，B，C
[A_opt, B_opt, C_opt,best_fitness,fitness_evolution,error_evolution,stability_evolution] = optimize_ABC3(D, A, B, C, alpha, batch_size, maxIter, Ps, LengthOfProblem);
elapsedTime = toc;
disp(['程序运行时间：', num2str(elapsedTime), ' 秒']);

save('optimized_parameters0702.mat', 'A_opt', 'B_opt', 'C_opt', 'D','best_fitness','fitness_evolution','error_evolution','stability_evolution','population');


% 绘制适应度演化曲线
figure;
plot(fitness_evolution, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Fitness');
title('Fitness Evolution');

% 绘制错误适应度和稳定性适应度的演化曲线
figure;
plot(error_evolution, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Error Fitness');
title('Error Fitness Evolution');

figure;
plot(stability_evolution, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Stability Fitness');
title('Stability Fitness Evolution');

figure;
subplot(3,1,1);
bar(A_opt);
xlabel('Individual');
ylabel('A');
title('Distribution of A');

subplot(3,1,2);
bar(B_opt);
xlabel('Individual');
ylabel('B');
title('Distribution of B');

subplot(3,1,3);
bar(C_opt);
xlabel('Individual');
ylabel('C');
title('Distribution of C');


% 保存优化后的参数
save('optimized_parameters0702.mat', 'A_opt', 'B_opt', 'C_opt', 'D','best_fitness','fitness_evolution','error_evolution','stability_evolution','population');





