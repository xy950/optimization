function weights_updated = update_weights(weights, gradient, alpha)
    % 使用梯度下降法更新权重
    weights_updated = weights - alpha * gradient;
end