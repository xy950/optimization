function [re,rc]=computeFK(theta,xb,yb)
theta1=theta(1);theta2=theta(2);theta3=theta(3);
theta4=theta(4);theta5=theta(5);
% m1=2.23;m2=5.28;m3=14.79;
% m4=m2;m5=m1;
% I1=0.033;I2=0.033;I3=0.033;I4=0.033;I5=0.033;
L1=0.332;L2=0.302;L3=0.486;L4=L2;L5=L1;
d1=0.189;d2=0.236;d3=0.282;d4=d2;d5=d1;
% xb=0;yb=0;

xe=xb-L1*sin(theta1)-L2*sin(theta2)+L4*sin(theta4)+L5*sin(theta5); %�ڶ���ĩ�˶˵��λ������
ye=yb+L1*cos(theta1)+L2*cos(theta2)-L4*cos(theta4)-L5*cos(theta5);

xc1=-d1*sin(theta1); %ÿ���������ĵ�����
yc1=d1*cos(theta1);
xc2=-L1*sin(theta1)-d2*sin(theta2);
yc2=L1*cos(theta1)+d2*cos(theta2);
xc3=-L1*sin(theta1)-L2*sin(theta2)-d3*sin(theta3);
yc3=L1*cos(theta1)+L2*cos(theta2)+d3*cos(theta3);
xc4=L1*sin(theta1)+L2*sin(theta2)-(L4-d4)*sin(theta4);
yc4=L1*cos(theta1)+L2*cos(theta2)-(L4-d4)*cos(theta4);
xc5=L1*sin(theta1)+L2*sin(theta2)-L4*sin(theta4)-(L5-d5)*sin(theta5);
yc5=L1*cos(theta1)+L2*cos(theta2)-L4*cos(theta4)-(L5-d5)*cos(theta5);

rc1=[xc1;yc1];rc2=[xc2;yc2];rc3=[xc3;yc3];rc4=[xc4;yc4];rc5=[xc5;yc5];
rc=[rc1 rc2 rc3 rc4 rc5];

xB=xb-L1*sin(theta1); %ÿ���˵������
yB=yb+L1*cos(theta1);
xC=xB-L2*sin(theta2);
yC=yB+L2*cos(theta2);
xD=xC-L3*sin(theta3);
yD=yC+L3*cos(theta3);
xE=xC+L4*sin(theta4);
yE=yC-L4*cos(theta4);

A=[xb;yb];
B=[xB;yB]; C=[xC;yC];
DD=[xD;yD]; E=[xE;yE]; F=[xe;ye];
re=[A B C DD E F];

end
