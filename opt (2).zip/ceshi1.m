clc
clear
t=0;
% for i=1:4000
%     clc
%     t=t+0.001;
% %     tt=linspace(0,40,100);
% sx=0.2*t;
% hh=sx*tand(5);
% hhh=sx/sind(5);
% plot(hhh);
% end
    plot([-10,10],[0,0]);
    hold on
 plot([-10,10],[0,0.1]);