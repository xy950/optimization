% 假设有7种方法，每种方法针对4个关节有一个性能值
% 以下是随机生成的性能数据
performance_data = rand(7, 4); % 7种方法，4个关节

% 给每种方法一个标签
method_labels = {'方法1', '方法2', '方法3', '方法4', '方法5', '方法6', '方法7'};

% 给每个关节一个标签
joint_labels = {'关节1', '关节2', '关节3', '关节4'};

% 为了雷达图闭合，复制每种方法第一个关节的性能到末尾
performance_data(end+1, :) = performance_data(1, :);

% 雷达图的角度
angles = linspace(0, 2 * pi, size(performance_data, 1));

% 开始绘图
figure;

% 对于每个关节绘制一个雷达图
for i = 1:4
    subplot(2, 2, i); % 4个子图的布局
    polarplot(angles, performance_data(:, i), 'o-'); % 绘制雷达图
    thetaticks(angles * 180/pi); % 设置角度标签
    thetaticklabels(method_labels); % 设置方法标签
    title(['雷达图 - ', joint_labels{i}]); % 设置每个子图的标题
    rlim([0 1]); % 假设性能数据被标准化到[0,1]区间
end

% 添加图例，因为所有子图数据都相同，所以只需要一个图例
legend(method_labels, 'Location', 'southoutside'); % 在底部添加图例

% 调整子图的间距以防止重叠
tight_layout();

% 显示图形
hold off;
