function stability_fitness = calculate_stability(dq)
stability_fitness = dq(1)^2 + dq(2)^2 + dq(3)^2 + dq(4)^2;
end
