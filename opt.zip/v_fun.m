% function velocity_goal=v_fun(tt)
% if tt<1
%     velocity_goal=0.3;
% elseif tt>=1 && tt<1.5
%     velocity_goal=0.35;
% elseif tt>=1.5 && tt<2
%     velocity_goal=0.4;
% elseif tt>=2 && tt<2.5
%     velocity_goal=0.45;
% elseif tt>=2
%     velocity_goal=0.5;
% end
% end

function velocity_goal=v_fun(tt)
if tt<1
    velocity_goal=0.2;
elseif tt>=1 && tt<2
    velocity_goal=0.3;
elseif tt>=2
    velocity_goal=0.3;
end
end

% function velocity_goal=v_fun(tt)
% if tt<1
%     velocity_goal=0.1;
% elseif tt>=1 && tt<1.5
%     velocity_goal=0.15;
% elseif tt>=1.5 && tt<2
%     velocity_goal=0.2;
% elseif tt>=2 
%     velocity_goal=0.3;
% % elseif tt>=2
% %     velocity_goal=0.3;
% end
% end