clc
clear
close all

data = cell(1, 7); % 初始化一个单元数组存储数据集
data{1} = xlsread('ga_qdq.xlsx');
data{2} = xlsread('mulga_qdq.xlsx');
data{3} = xlsread('particle_qdq.xlsx');
data{4} = xlsread('ps_qdq.xlsx');
data{5} = xlsread('sa_qdq.xlsx');
data{6} = xlsread('manual_qdq.xlsx');
data{7} = xlsread('psystem_qdq.xlsx');

% 创建图形窗口
figure;

% 遍历每个关节和每种方法
for i = 1:4 % 对于4个关节
    for j = 1:7 % 对于7种方法
        % 计算子图位置
        subplotIndex = (i - 1) * 7 + j;
        subplot(4, 7, subplotIndex); % 选择子图位置
        
        
        % 绘制数据，这里我们只是用线性索引绘制对应的数据
        plot(data{j}(2:2000, i*2));
        hold on
        plot(data{j}(2:2000, i*2-1));
        
        % 添加标题
        title(sprintf('Joint %d, Method %d', i, j));
        
        % 可以选择只在外围子图显示坐标轴标签
        if i ~= 4
            set(gca, 'XTickLabel', []); % 隐藏除了最下面一行之外的所有x轴标签
        end
        if j ~= 1
            set(gca, 'YTickLabel', []); % 隐藏除了最左边一列之外的所有y轴标签
        end
        
        % 设置一个限制，使得所有子图的坐标轴都相同
        xlim([1 N]); % 假设时间序列或试验次数为1到N
    end
end