function [tau,q4_goal,q3_goal,q1_goal,q2_goal,Rflag,q,dq,xx,yy,x_apex]=Controller_A(z0,t,velocity_body,xb,yb,i,e_new,Rflag,x_tau,mohu33,mohu44)
kp=-100;kd=1;
q=[1 -1 0 0 0;0 1 -1 0 0;0 0 1 1 0;0 0 0 1 -1 ]*z0(1:5,1);
dq=[1 -1 0 0 0;0 1 -1 0 0;0 0 1 1 0;0 0 0 1 -1 ]*z0(6:10,1);
theta1=z0(1);theta2=z0(2);theta3=z0(3);theta4=z0(4);theta5=z0(5);

q1_c=z0(1)-z0(2);q2_c=z0(2)-z0(3);q3_c=z0(3)+z0(4);q4_c=z0(4)-z0(5);%��Խǵ�ǰֵ
dq1_c=z0(6)-z0(7);dq2_c=z0(7)-z0(8);dq3_c=z0(8)+z0(9);dq4_c=z0(9)-z0(10);%��Խ��ٶȵ�ǰֵ
theta1=z0(1);theta2=z0(2);theta3=z0(3);theta4=z0(4);theta5=z0(5);%���Խǵ�ǰֵ
dtheta1=z0(6);dtheta2=z0(7);dtheta3=z0(8);dtheta4=z0(9);dtheta5=z0(10);%���Խ��ٶȵ�ǰֵ


%  T = [tau1;tau2 - tau1;tau3 - tau2;tau3 + tau4;-tau4];
%  T=[0;tau1;tau2;tau3;tau4];

                                                                    
tau(1)=-500*(q(1)-0.1)-50*dq(1); %֧���ȵ�ϥ�ؽڵ����ؿ��ƣ�Ŀ���ǿ����ȳ��̶���ʹ֧���Ȳ�������
tau(2)=1000*(z0(3)-0.1)+100*z0(8); %֧���ȵ��Źؽڵ����ؿ��ƣ�Ŀ���ǿ���������
tau(3)=-500*(q(3)-0.1)-50*dq(3); %�ڶ��ȵ��Źؽ�
tau(4)=-100*(q(4)-0.5)-10*dq(4); %�ڶ��ȵ�ϥ�ؽ�
L1=0.332;L2=0.302;L3=0.486;L4=L2;L5=L1;
g=9.8;
% T_step=0.26;
yCset=0.634;
yC=0.634;%%��ʱ�����ĸ߶���Ϊ��ֵ
xC=0;%x_body;
yC=(L1+L2)*cos(theta1);
K=-1;
T_step=0.4;
q_normal = 360*pi/180;      % [rad]
dq_normal = 180*pi/180; % [rad/s]
u_normal = 1000;     % [N]
% k=0.2;
% kp=0.1;
% 
% velocity_goal=0.3;
% E=0.5*velocity_goal^2;
     tt=0.001*i;
     ttt=0.001*(i-1);
%      velocity_goal=v_fun(tt);
     velocity_goal=0.3;
     x_apex=velocity_goal*T_step/2+e_new;
     %x_apex=velocity_goal*T_step/2;

fprintf("x_apex=%f\n",x_apex);
% % fprintf("kp=%f\n",kp);
fprintf("i=%f\n",i);
fprintf("e_new=%f\n",e_new);
%fprintf("tt=%f\n",tt);
% % % fprintf("sum_a=%f\n",sum_a);
% % % fprintf("a(i)=%f\n",a(i));

xx=0;
yy=0;
height_rising=0.07; 
% % kp4=-300;kd4=-30;
% persistent yCset;
persistent yy_record;
if(t<T_step/2)
    yCset=yC;
    [xx1,dxx1,~]=motionplanning([0,0],[x_apex/2 0],0,T_step/2,t);
    [yy1,dyy1,~]=motionplanning([0,0],[height_rising 0],0,T_step/2,t);
    xx=xx1;
    yy=yCset-yy1;
    yy_record=yC;
    if ((xx^2+yy^2)>=(L4+L5)^2)%x,y���굽ԭ��ľ��벻�ܳ����ȳ�
        xx=xx*(L4+L5-0.01)/sqrt(xx^2+yy^2);
        yy=yy*(L4+L5-0.01)/sqrt(xx^2+yy^2);
    end
    
    if ~isreal(xx)
        ME=MException('MyComponent:noSuchVariable','���ָ���');
        disp(tau);
        throw(ME);
    end
    
    
    theta4= 2*atan((2*L4*xx - (- L4^4 + 2*L4^2*L5^2 + 2*L4^2*xx^2 + 2*L4^2*yy^2 - L5^4 + 2*L5^2*xx^2 + 2*L5^2*yy^2 - xx^4 - 2*xx^2*yy^2 - yy^4)^(1/2))/(L4^2 + 2*L4*yy - L5^2 + xx^2 + yy^2));
    theta5= 2*atan((2*L5*xx + ((- L4^2 + 2*L4*L5 - L5^2 + xx^2 + yy^2)*(L4^2 + 2*L4*L5 + L5^2 - xx^2 - yy^2))^(1/2))/(- L4^2 + L5^2 + 2*L5*yy + xx^2 + yy^2));
    q1=theta1-theta2; q2=theta2-theta3; q3=theta3+theta4; q4=theta4-theta5;
    q3_goal=-q3;
    q4_goal=-q4;
    q1_goal=-0.5;
    q2_goal=theta2;
    e_q1=q(1)+0.5;
    e_q2=q(2)-q2_goal;
    
% %     if e_q1>0
% %         tau(1)=-1000*(q(1)+0.5)-100*(dq(1)-0);
% %     else
% %         tau(1)=-1000*(q(1)+0.5)-150*(dq(1)-0);
% %     end

%       n11(i)=q31_goal;      
%     n11(i)=0.99*q3_goal+0.01*n11(i);    
%    q31_goal=n11(i);
%    q3_goal= n11(i);
%    tau(1)=x_tau(1);
%    tau(2)=x_tau(2);
%    tau(3)=x_tau(3);
%    tau(4)=x_tau(4);
% if(t<T_step*0.55)
kp1=1000;kp2=1000;kp3=250;kp4=300;
kd1=100;kd2=100;kd3=25;kd4=7;
c=-0.08;
    tau(1)=-kp1*(q(1)+0.5)-kd1*dq(1)+0;%x_tau(1); %֧���ȵ�ϥ�ؽڵ����ؿ��ƣ�Ŀ���ǿ����ȳ��̶���ʹ֧���Ȳ�������
    tau(2)=kp2*(z0(3)+0)+kd2*z0(8)+ 0;%x_tau(2); %֧���ȵ��Źؽڵ����ؿ��ƣ�Ŀ���ǿ���������
    e_q3=q(3)-q3_goal;
    e_q4=q(4)-q4_goal;
    de_q3=(q(3)-q3_goal)/0.001;
    de_q4=(q(4)-q4_goal)/0.001;
    
       mohu3=-defuzzification(fuzzy_inference(fuzzification(e_q3/q_normal, de_q3/dq_normal))) * u_normal*2;
       mohu4=-defuzzification(fuzzy_inference(fuzzification(e_q4/q_normal, de_q4/dq_normal))) * u_normal*2;
%       tau(3)=mohu3;
     if e_q3<c %0
       
    m11(i)=mohu33;        
    m11(i)=0.03*mohu3+0.97*m11(i);    
   tau(3) = m11(i);
   mohu33=m11(i);
     else
   tau(3)=-kp3*(q(3)-q3_goal)-kd3*(dq(3)-0);
  
     end
     
tau(4)=-kp4*(q(4)-q4_goal)-kd4*(dq(4)-0);

kpkd=[kp1,kp2,kp3,kp4,kd1,kd2,kd3,kd4,c];
assignin('base','kpkd',kpkd);

else
    
    if(t>T_step) t=T_step; end%ʱ�䲻�ܳ����趨����0.4
    [xx2,dxx2,~]=motionplanning([x_apex/2,0],[x_apex 0],T_step/2,T_step,t);
    [yy2,dyy2,~]=motionplanning([yCset-(yy_record-height_rising),0],[0.00 0],T_step/2,T_step,t);
    xx=xx2;
    yy=yCset-yy2;
    while ((xx^2+yy^2)>=(L4+L5)^2)
        xx=xx*(L4+L5-0.01)/sqrt(xx^2+yy^2);
        yy=yy*(L4+L5-0.01)/sqrt(xx^2+yy^2);
    end
    
%     xx=xx1;
%     yy=yC-yy1;
%     if ((xx^2+yy^2)>=(L4+L5-0.01)^2)%x,y���굽ԭ��ľ��벻�ܳ����ȳ�
%         xx=xx*(L4+L5-0.01)/sqrt(xx^2+yy^2);
%         yy=yy*(L4+L5-0.01)/sqrt(xx^2+yy^2);
%     end
    
    
    theta4= 2*atan((2*L4*xx - (- L4^4 + 2*L4^2*L5^2 + 2*L4^2*xx^2 + 2*L4^2*yy^2 - L5^4 + 2*L5^2*xx^2 + 2*L5^2*yy^2 - xx^4 - 2*xx^2*yy^2 - yy^4)^(1/2))/(L4^2 + 2*L4*yy - L5^2 + xx^2 + yy^2));
    theta5= 2*atan((2*L5*xx + ((- L4^2 + 2*L4*L5 - L5^2 + xx^2 + yy^2)*(L4^2 + 2*L4*L5 + L5^2 - xx^2 - yy^2))^(1/2))/(- L4^2 + L5^2 + 2*L5*yy + xx^2 + yy^2));

    q1=theta1-theta2; q2=theta2-theta3; q3=theta3+theta4; q4=theta4-theta5;
    q3_goal=-q3;
    q4_goal=-q4;
    q1_goal=-0.5;
    q2_goal=theta2;
    
    e_q3=q(3)-q3_goal;
    e_q4=q(4)-q4_goal;
    de_q3=(q(3)-q3_goal)/0.001;
    de_q4=(q(4)-q4_goal)/0.001;
    e_q1=q(1)+0.5;
    e_q2=q(2)-q2_goal;
    
%     if e_q1>0
%         tau(1)=-500*(q(1)+0.5)-50*(dq(1)-0);
%     else
%         tau(1)=-1000*(q(1)+0.5)-150*(dq(1)-0);
%     end
    
%     if(t>=T_step*0.55)
        
    tau(1)=-500*(q(1)+0.5)-50*dq(1)+0;%x_tau(1); %֧���ȵ�ϥ�ؽڵ����ؿ��ƣ�Ŀ���ǿ����ȳ��̶���ʹ֧���Ȳ�������
    tau(2)=1000*(z0(3)+0)+100*z0(8)+0;%x_tau(2); %֧���ȵ��Źؽڵ����ؿ��ƣ�Ŀ���ǿ���������
    %%tau(3)=-500*(q(3)-0.3*(velocity_body+0.5)-0.015*acc)-50*dq(3); %�ڶ��ȵ��Źؽ�
    %%tau(4)=-100*(q(4)-0.1)-10*dq(4); %�ڶ��ȵ�ϥ�ؽ�


       mohu3=-defuzzification(fuzzy_inference(fuzzification(e_q3/q_normal, de_q3/dq_normal))) * u_normal*2;
%       tau(3)=mohu3;
% %      if e_q3<0
% %        
% %     m11(i)=mohu33;        
% %     m11(i)=0.01*mohu3+0.99*m11(i);    
% %    tau(3) = m11(i);
% %    mohu33=m11(i);
% %      else
   tau(3)=-250*(q(3)-q3_goal)-25*(dq(3)-0);
% %      end
   
   

   tau(4)=-300*(q(4)-q4_goal)-30*(dq(4)-0);
%    tau(4)=-100*(q(4)-q4_goal)-10*(dq(4)-0);

fprintf("Ŀ��ĩ��λ�ã�\t%f\t%f\n",xx,yy);
   
Max_Torque=500;
tau(1)=max(-Max_Torque,min(Max_Torque,tau(1)));
tau(2)=max(-Max_Torque,min(Max_Torque,tau(2)));
tau(3)=max(-Max_Torque,min(Max_Torque,tau(3)));
tau(4)=max(-Max_Torque,min(Max_Torque,tau(4)));
% % % if Rflag==1
% % %     q4_record=[q4_record,q(4)];
% % % else
% % %     q4_record=[q4_record,q(1)];
% % % end
    
% tau=[0 0 0 0];

end