clc
clear
close all

tic;

% 参数数量
num_vars = 11;

% 初始范围
lower_bounds = [zeros(1, 8), 0, 0, 0];
upper_bounds = [1000*ones(1, 4), 500*ones(1, 4), 5, 1, 1];

% 使用遗传算法进行优化
options = optimoptions('gamultiobj', 'OutputFcn', @gaoutfun, 'PopulationSize', 30, 'MaxGenerations', 60,'Display', 'iter');
[x, fval] = gamultiobj(@fitnessFunc, num_vars, [], [], [], [], lower_bounds, upper_bounds, @nonlcon, options);

% options = optimoptions('ga', 'OutputFcn', @gaoutfun, 'PopulationSize', 25, 'MaxGenerations', 50);
% [x, fval] = ga(@fitnessFunc, num_vars, [], [], [], [], lower_bounds, upper_bounds, @nonlcon, [], options);

% 输出最优解
disp(x);
toc;
elapsedTime = toc;
fprintf('Total time taken: %.2f seconds\n', elapsedTime);

% 绘图
% 获取x的历史数据
xHistory = evalin('base','xHistory');

if ~isempty(xHistory)
    figure(2);
    hold on;
    %figure(2)
    for i = 1:num_vars
        plot(1:size(xHistory, 1), xHistory(:, i));
    end
    title('x Values over Generations');
    xlabel('Generation');
    ylabel('Values');
    legend(arrayfun(@(i) sprintf('x%d', i), 1:num_vars, 'UniformOutput', false));
    hold off;
end

% 首先从基础工作区获取历史数据
fit1History = evalin('base','fit1History');
fit2History = evalin('base','fit2History');
fitnessHistory = evalin('base','fitnessHistory');

figure(3);
plot(1:length(fitnessHistory), fitnessHistory);
title('Fitness Values over Generations');
xlabel('Generation');
ylabel('Fitness Value');

figure(4);
plot(1:length(fit1History), fit1History, 'b');
hold on;
plot(1:length(fit2History), fit2History, 'r');
title('Fit1 and Fit2 Values over Generations');
xlabel('Generation');
ylabel('Values');
legend('Fit1', 'Fit2');

figure(5);
plot(fit1History, fit2History, 'o');
title('Pareto Front');
xlabel('Fitness 1');
ylabel('Fitness 2');

figure(6);
plot(fval(:, 1), fval(:, 2), 'o');
title('Pareto Front');
xlabel('Objective 1');
ylabel('Objective 2');

% 生成唯一的文件名，例如基于当前日期和时间
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
filename = ['workspace_', timestamp, '.mat'];

% 保存工作区数据到MAT文件
save(filename);

function [y,fit1,fit2] = fitnessFunc(x)
    A = x(1:4);
    B = x(5:8);
    C = x(9);
    d1 = x(10);
    d2 = x(11);

    [error_fitness,stability_fitness,fitness]= evaluate_fitness2(A,B,C);

    % TODO: 插入用于计算fit1和fit2的代码
    fit1 = error_fitness;
    fit2 = stability_fitness;

    y = [fit1, fit2]; % 返回一个向量，每个元素代表一个目标
end


function [z, ceq] = nonlcon(x)
    d1 = x(10);
    d2 = x(11);

    z = [];  % No nonlinear inequality constraints
    ceq = d1 + d2 - 1;  % The nonlinear equality constraint
end

function [state,options,optchanged] = gaoutfun(options,state,flag)
    persistent fit1History fit2History xHistory fitnessHistory

    if isempty(fit1History)
        [~, bestIndividualIdx] = min(sum(state.Score, 2));
        bestIndividual = state.Population(bestIndividualIdx, :);
        [~,fit1, fit2] = fitnessFunc(bestIndividual);
        fit1History = fit1;
        fit2History = fit2;
        xHistory = bestIndividual;
        fitnessHistory = sum(state.Score, 2); 
    else      
        [~, bestIndividualIdx] = min(sum(state.Score, 2));
        bestIndividual = state.Population(bestIndividualIdx, :);
        [~,fit1, fit2] = fitnessFunc(bestIndividual);
        fit1History = [fit1History; fit1];
        fit2History = [fit2History; fit2];
        xHistory = [xHistory; bestIndividual];
        fitnessHistory = [fitnessHistory; sum(state.Score, 2)]; 
    end
    disp(['Current generation: ', num2str(state.Generation)]);
    assignin('base','fit1History',fit1History);
    assignin('base','fit2History',fit2History);
    assignin('base','fitnessHistory',fitnessHistory);
    assignin('base','xHistory',xHistory);
    optchanged = false;
end

