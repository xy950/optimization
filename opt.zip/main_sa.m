clc
clear
close all


% options = optimoptions('simulannealbnd','MaxIterations',2);
options = optimoptions('simulannealbnd', 'MaxIterations', 50, 'OutputFcn', @myfun);
nvars = 10; % 参数数量
lb = zeros(1, nvars); % 下界
ub = [1000*ones(1, 4),500*ones(1, 4), 5, 1]; % 上界
x0 = rand(1, nvars); % 初始解
[x,fval,exitflag,output]  = simulannealbnd(@calculateFitness,x0,lb,ub,options);


% 输出最优解
disp(x);

figure(1);
bar(x);
xlabel('Parameter Index');
ylabel('Optimal Value');
title('Optimized Parameters');

% 获取历史数据
history = evalin('base', 'history');
figure(2);
for i = 1:nvars
    subplot(nvars, 1, i);
    plot(history(:, i));
    ylabel(['Parameter ', num2str(i)]);
end
xlabel('Iteration');

% 获取最优参数历史数据
bestxHistory = evalin('base', 'bestxHistory');
figure(3);
for i = 1:nvars
    subplot(nvars, 1, i);
    plot(bestxHistory(:, i));
    ylabel(['Best Parameter ', num2str(i)]);
end
xlabel('Iteration');


% 获取适应度历史数据
fvalHistory = evalin('base', 'fit_history');
bestfvalHistory = evalin('base', 'bestfvalHistory');
figure(4);
plot(fvalHistory);
hold on;
plot(bestfvalHistory);
xlabel('Iteration');
ylabel('Fitness Value');
legend('Fitness','Best Fitness');
title('Fitness History');

%画出fit1和fit2的历史数据和最优数据
figure(5);
plot(evalin('base', 'fit1_history'));
hold on;
plot(evalin('base', 'best_fit1_history'));
xlabel('Iteration');
ylabel('Fitness Value');
legend('Fit1','Best Fit1');
title('Fit1 History');

figure(6);
plot(evalin('base', 'fit2_history'));
hold on;
plot(evalin('base', 'best_fit2_history'));
xlabel('Iteration');
ylabel('Fitness Value');
legend('Fit2','Best Fit2');
title('Fit2 History');

figure(7);
plot(evalin('base', 'd2_history'));
hold on;
plot(evalin('base', 'best_d2_history'));
xlabel('Iteration');
ylabel('d2 Value');
legend('d2','Best d2');
title('d2 History');

% 生成唯一的文件名，例如基于当前日期和时间
timestamp = datestr(now, 'yyyymmdd_HHMMSS');
filename = ['workspace_', timestamp, '.mat'];

% 保存工作区数据到MAT文件
save(filename);


function fit = calculateFitness(params)
    persistent history fit_history fit1_history fit2_history
    persistent best_fit1 best_fit2 best_fit1_history best_fit2_history
    persistent d2_history best_d2 best_d2_history

    if isempty(history)
        history = [];
        fit_history = [];
        fit1_history = [];
        fit2_history = [];
        best_fit1 = inf;  % Assuming a minimization problem
        best_fit2 = inf;  % Assuming a minimization problem
        best_fit1_history = [];  % History of best fit1
        best_fit2_history = [];  % History of best fit2
        d2_history = [];
        best_d2 = inf;
        best_d2_history = [];
    end

    A = params(1:4); % PD控制器参数c1
    B = params(5:8); % PD控制器参数c2
    C = params(9); % 阈值a
    d1 = params(10);
%     d2 = params(11);
    d2=1-d1;
    
    % 计算 fit1 和 fit2
    % 这将取决于你的具体模型和控制策略

    [error_fitness,stability_fitness,fitness]= evaluate_fitness2(A,B,C);

    % TODO: 插入用于计算fit1和fit2的代码
    fit1 = error_fitness;
    fit2 = stability_fitness;
    
    % 计算总的适应度
    fit = d1 * fit1 + d2 * fit2;

    % Save params and fitness values
    history = [history; params];
    fit_history = [fit_history; fit];
    fit1_history = [fit1_history; fit1];
    fit2_history = [fit2_history; fit2];

    d2 = 1 - d1;
    d2_history = [d2_history; d2];
    if d2 < best_d2
        best_d2 = d2;
    end
    best_d2_history = [best_d2_history; best_d2];

    if fit1 < best_fit1
        best_fit1 = fit1;
    end

    if fit2 < best_fit2
        best_fit2 = fit2;
    end

     % Save the history of the best fits
    best_fit1_history = [best_fit1_history; best_fit1];
    best_fit2_history = [best_fit2_history; best_fit2];


    % Assign variables to base workspace for later access
    assignin('base', 'history', history);
    assignin('base', 'fit_history', fit_history);
    assignin('base', 'fit1_history', fit1_history);
    assignin('base', 'fit2_history', fit2_history);
    assignin('base', 'best_fit1', best_fit1);
    assignin('base', 'best_fit2', best_fit2);
    assignin('base', 'best_fit1_history', best_fit1_history);
    assignin('base', 'best_fit2_history', best_fit2_history);
    assignin('base', 'd2_history', d2_history);
    assignin('base', 'best_d2', best_d2);
    assignin('base', 'best_d2_history', best_d2_history);
end

function [stop, options, optchanged] = myfun(options, optimValues, flag)
    persistent bestxHistory bestfvalHistory
    stop = false; % 这是必须的，表示优化是否应该停止
    optchanged = false; % 初始化为false，除非我们确实更改了选项

    % 检查是否在迭代过程中或完成状态，若是，则保存最优解和最优适应度值
    if strcmp(flag,'iter') || strcmp(flag,'done')
        if isempty(bestxHistory)
            bestxHistory = optimValues.bestx;
            bestfvalHistory = optimValues.bestfval;
        else
            bestxHistory = [bestxHistory; optimValues.bestx];
            bestfvalHistory = [bestfvalHistory; optimValues.bestfval];
        end

        % 保存历史信息到'base'工作区
        assignin('base', 'bestxHistory', bestxHistory);
        assignin('base', 'bestfvalHistory', bestfvalHistory);
    end
end





