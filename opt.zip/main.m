clear functions
close all
clear all
clc

tic;

ToRad = pi/180;
ToAngle = 180/pi;
time_number=1000;
T=0.4;
options=odeset('abstol',1e-9,'reltol',1e-9);
z0 = [0*ToRad 0*ToRad 0*ToRad 0*ToRad 0*ToRad 0 0 0 0 0];
tau = [0 0 0 0]';
tspan=linspace(0,0.001,101);
xe=0;ye=0;
t=0;
% T=10;%
test_record=[];
test_record1=[];
xbody_record=[];
tau1_record=[]; tau2_record=[]; tau3_record=[]; tau4_record=[];
phase_record=[];
q4goal_record=[];
q3goal_record=[];
q1goal_record=[];
q2goal_record=[];
q4_record=[];
q3_record=[];
q1_record=[];
q2_record=[];
eq3_record=[];
dq3_record=[];dq4_record=[];dq1_record=[];dq2_record=[];
xe_record=[];
e_vector=[];
de_vector=[];
t_record=[];
yy_record=[];
xx_record=[];
xe_record=[];
ye_record=[];
x_apex_record=[];
enew_record=[];
q31_goal=0;
mohu33=0;
mohu44=0;
a=[];
x_body=0;
velocity_temp=0;
acc_temp=0;
xb=0;
yb=0;
yC=0.6;
sum_a=0;sum_alast=0;
sx=0;hh=0;ttt=0;
% velocity_goal=0;
% % kp=0;
for i=1:5000
    clc
    t=t+0.001;
    
    [t1213,x_theta]=ode113('compute_state',tspan,z0,options,tau);
    
    x0=x_theta(end,:);
    z0=x0;
%     for j=1:5
%         if(z0(j)>pi/2) z0(j)=z0(j)-pi; end
%         if(z0(j)<-pi/2) z0(j)=z0(j)+pi; end
%     end
            
    theta1=x0(1);theta2=x0(2);theta3=x0(3);
    theta4=x0(4);theta5=x0(5);
    dtheta1=x0(6);dtheta2=x0(7);dtheta3=x0(8);
    dtheta4=x0(9);dtheta5=x0(10);
    theta=[theta1 theta2 theta3 theta4 theta5]';
    dtheta=[dtheta1;dtheta2;dtheta3;dtheta4;dtheta5];
    [re,rc]=computeFK(theta,xb,yb);
    xb=re(1,1);
    yb=re(2,1);
    re(1,:)=re(1,:)+xe;
    re(2,:)=re(2,:)+ye;
    rc(1,:)=rc(1,:)+xe;
    rc(2,:)=rc(2,:)+ye;
%     xe=re(1,end);ye=re(2,end);
   tt=0.001*i;
    velocity_goal=v_fun(tt);
    kp=0.1+0.01*tt;
    kp=-kp;
     k=0.6;
%       kp=0;
%       k=0;
    velocity_body=(rc(1,3)-x_body)/0.001;
    velocity_body=0.9*velocity_temp+0.1*velocity_body;
    velocity_temp=velocity_body;
    e_body=velocity_body-velocity_goal;
    e_vector(i)=e_body;
    if i>1
        de_vector(i)=(e_vector(i)-e_vector(i-1))/0.001;
    else
       de_vector(i)=0;  
    end
    acc=de_vector(i);
    acc=0.75*acc_temp+0.25*acc;
    acc_temp=acc;

    if i==1
        e_new=kp*e_body;
    else
            if e_vector(i)*de_vector(i)<0||de_vector(i)==0
            e_new=kp*e_body-0.01*acc;%k*kp*sum_a-0.01*acc;
            else
            e_new=kp*e_body+k*kp*e_body;%-0.01*acc;%sum_alast-0.01*acc; 
            end
    end


%     e_new=kp*e_body-0.01*acc;
    x_body=rc(1,3);    
    theta_input=[theta' dtheta']';
    Rflag=1;Lflag=0;
    
    if re(2,end)<= -0.001&&t>T/4%-0.005
        t=0;
        theta_output=impact_model(theta_input);
        theta1=theta_output(5);
        theta2=theta_output(4);
        theta3=theta_output(3);
        theta4=theta_output(2);
        theta5=theta_output(1);
        dtheta1=theta_output(10);
        dtheta2=theta_output(9);
        dtheta3=theta_output(8);
        dtheta4=theta_output(7);
        dtheta5=theta_output(6);
        theta=[theta1 theta2 theta3 theta4 theta5]';
        dtheta=[dtheta1;dtheta2;dtheta3;dtheta4;dtheta5];
        
        xe=re(1,end);ye=re(2,end);        
        xe_record=[xe_record,xe];
        z0=[theta',dtheta'];
        Rflag=0;Lflag=1;
    end
% 
%       xe=re(1,end);ye=re(2,end);   
    x_tau=compute_x_tau_state(t,z0,flag,x_theta);
%     [tau,q4_goal,q3_goal,Rflag,q,dq,xx,yyyy]=Controller_A(z0',t,velocity_body,xb,yb,i,e_new,Rflag,x_tau,mohu33,q31_goal)
     [tau,q4_goal,q3_goal,q1_goal,q2_goal,Rflag,q,dq,xx,yyyy,x_apex]=Controller_A(z0',t,velocity_body,xb,yb,i,e_new,Rflag,x_tau,mohu33,mohu44);
% %     q4_record=[q4_record,q(4)];
%     if Rflag==1
%         q1goal_record=[q1goal_record,q1_goal];
%         q2goal_record=[q2goal_record,q2_goal];
%         q1_record=[q1_record,q(1)];
%         q2_record=[q2_record,q(2)];
%         q4goal_record=[q4goal_record,q4_goal];
%         q3goal_record=[q3goal_record,q3_goal];
%         q4_record=[q4_record,q(4)];
%         q3_record=[q3_record,q(3)];
%     else
%         q1goal_record=[q1goal_record,q4_goal];
%         q2goal_record=[q2goal_record,q3_goal];
%         q1_record=[q1_record,q(4)];
%         q2_record=[q2_record,q(3)];
%         q4goal_record=[q4goal_record,q1_goal];
%         q3goal_record=[q3goal_record,q2_goal];
%         q4_record=[q4_record,q(1)];
%         q3_record=[q3_record,q(2)];
%     end

    fprintf("e_vector(%d)=%f\t de_vector(%d)=%f",i,e_vector(i),i,de_vector(i));
    fprintf("sum_a=%f\n",sum_a);
    fprintf("kp=%f\n",kp);
    fprintf("��������Time:%f\nTorque:%f\t%f\t%f\t%f\n",t,tau(1),tau(2),tau(3),tau(4));
    fprintf("���Խ�Angle(rad):\t%f\t%f\t%f\t%f\t%f\n",z0(1),z0(2),z0(3),z0(4),z0(5));
    fprintf("���Խ�Angle(deg):\t%f\t%f\t%f\t%f\t%f\n",z0(1)*57.3,z0(2)*57.3,z0(3)*57.3,z0(4)*57.3,z0(5)*57.3);
    q=[1 -1 0 0 0;0 1 -1 0 0;0 0 1 1 0;0 0 0 1 -1 ]*z0(1,1:5)';
    dq=[1 -1 0 0 0;0 1 -1 0 0;0 0 1 1 0;0 0 0 1 -1 ]*z0(1,6:10)';
    fprintf("��Խ�Angle(rad):\t%f\t%f\t%f\t%f\n",q(1),q(2),q(3),q(4));
    fprintf("����Velocity:%f\n",velocity_body);
    fprintf("����ACC:\t\t%f\n",acc);
    disp (i);
    disp(xe);
    disp(rc(1,3));
    x_f=[re(1,1),re(1,2),re(1,3),re(1,4),re(1,3),re(1,5),re(1,6)];
    y_f=[re(2,1),re(2,2),re(2,3),re(2,4),re(2,3),re(2,5),re(2,6)];
% %     plot(x_f,y_f,'Linewidth',1),axis equal,xlim([-1 1]),ylim([-1 1])
% %     hold on;
% %     plot([-10,10],[0,0]);
% %     hold on
% % 
% %     xlim([-1+x_body 1+x_body]),ylim([-0.5 1.5])
% %     hold off;
% % %     plot(x_f,y_f),xlim([-1 1]),ylim([-1 1])
% %     pause(0.0000001);
    if (mod(i,60)==0)
    plot(x_f,y_f,'Linewidth',1),axis equal,xlim([-1 1]),ylim([-1 1])
    hold on;
    plot([-10,10],[0,0],'k','linewidth',1);
    xlim([-1+x_body 1+x_body]),ylim([-0.5 1.5])
% xlim([-0.5 1.5]),ylim([-0.5 1.5])
    hold off;
%     plot(x_f,y_f),xlim([-1 1]),ylim([-1 1])
    pause(0.01);
    hold on
    end
    
%     test_record=[test_record,[velocity_body,rc(1,3)]'];
    test_record=[test_record,velocity_body];
    xbody_record=[xbody_record,[x_body,t]'];
    tau1_record=[tau1_record,tau(1)];
    tau2_record=[tau2_record,tau(2)];
    tau3_record=[tau3_record,tau(3)];
    tau4_record=[tau4_record,tau(4)];
%     test_record1=[test_record1,e_new+0.01*acc];
    t_record=[t_record,t];
    eq3_record=[eq3_record,q(3)-q3_goal];
%     q4goal_record=[q4goal_record,q4_goal];
%     q3goal_record=[q3goal_record,q3_goal];
        q1goal_record=[q1goal_record,q1_goal];
        q2goal_record=[q2goal_record,q2_goal];
        q1_record=[q1_record,q(1)];
        q2_record=[q2_record,q(2)];
        q4goal_record=[q4goal_record,q4_goal];
        q3goal_record=[q3goal_record,q3_goal];
        q4_record=[q4_record,q(4)];
        q3_record=[q3_record,q(3)];
    dq1_record=[dq1_record,dq(1)];
    dq2_record=[dq2_record,dq(2)];
    dq3_record=[dq3_record,dq(3)];
    dq4_record=[dq4_record,dq(4)];
    yy_record=[yy_record,yyyy];
    xx_record=[xx_record,xx];
%     xe_record=[xe_record,xe];
    ye_record=[ye_record,ye];
    x_apex_record=[x_apex_record,x_apex];
    enew_record=[enew_record,e_new];
%     phase_record=[phase_record,[e_v,acc]'];
%     xe_record=[xe_record,[xe,t]'];
   
end

figure,plot(test_record);%�ٶ�
figure,plot(xbody_record(1,:));%λ��
% figure,plot(test_record1(1,:));
figure,plot(t_record(1,:));
figure,plot(tau1_record);
hold on
plot(tau2_record);
hold on
plot(tau3_record);
hold on
plot(tau4_record);
figure,plot(q1goal_record(1,:),'b','linewidth',1);
hold on
plot(q1_record(1,:),'r--','linewidth',1);
title('q1���ظ���','fontsize',15)
legend({'q1Ŀ��ֵ','q1ʵ�����'},'location','southwest')

figure,plot(q2goal_record(1,:),'b','linewidth',1);
hold on
plot(q2_record(1,:),'r--','linewidth',1);
title('q2���ظ���','fontsize',15)
legend({'q2Ŀ��ֵ','q2ʵ�����'},'location','southwest')
figure,plot(q3goal_record(1,:));
hold on
plot(q3_record(1,:));
figure,plot(q3goal_record(1,:)-q3_record(1,:));
figure,plot(q4goal_record(1,:));
hold on
plot(q4_record(1,:));
figure,plot(q4goal_record(1,:)-q4_record(1,:));
figure,plot(yy_record);
figure,plot(xx_record);
figure,plot(xe_record);
figure,plot(ye_record);
figure,plot(x_apex_record);
figure,plot(q3_record,dq3_record);
figure,plot(q4_record,dq4_record);
figure,plot(enew_record);
figure,plot(q1_record,dq1_record);
figure,plot(q2_record,dq2_record);
% figure,plot(phase_record(1,:),phase_record(2,:));

times=toc;

% ��ȡ��ǰ���ں�ʱ��
current_datetime = datestr(now, 'yyyy-mm-dd_HH-MM-SS');

% �����ļ���
filename = ['workspace_', current_datetime, '.mat'];

% ���浱ǰ��������ָ���ļ���
save(filename);

        
    